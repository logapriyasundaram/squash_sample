package com.example.myapplication.net;

public enum Status {
    LOADING,
    SUCCESS,
    ERROR
}