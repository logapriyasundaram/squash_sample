package com.example.myapplication.utils;

import android.app.Dialog;

public interface DialogClickListner {
    public void onClick(int ClickedId, Dialog dialog, String data);
}