package com.example.myapplication.net;

public class WebserviceUrls {

    public static final String BASE_URL = "http://rathinam.virtuze.in/api/v1/";
    public static final String BASE_URL1 = "http://trans.virtuze.in/api/";
    public static final String LOGIN = "login.php";
    public static final String GET_LUBEDB = "getLubeDB.php";
    public static final String GETCUSTOMERVEHICLENUMBER = "getCustomerByVehicleNumber.php";
    public static final String SAVEDETAIL = "updateEntryDetails.php";
    public static final String SENDMSG = "sendmsg.php";
    public static final String FEEDBACK = "postFeedback.php";

}
