package com.example.myapplication.di.module;




import com.example.myapplication.ui.login.LoginActivity;

import dagger.Module;
import dagger.android.ContributesAndroidInjector;

@Module
public abstract class ActivityBindingModule {



    @ContributesAndroidInjector
    abstract LoginActivity bindLoginActivity();


}
