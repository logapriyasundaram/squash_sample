package com.example.myapplication.ui.splash;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.Nullable;

import com.example.myapplication.R;
import com.example.myapplication.base.BaseActivity;
import com.example.myapplication.net.BaseUrlHolder;
import com.example.myapplication.net.WebserviceUrls;
import com.example.myapplication.ui.login.LoginActivity;
import com.example.myapplication.utils.Utils;


@SuppressLint("Registered")
public class SplashScreenActivity extends BaseActivity {

    private static final int MINUTE = 1000;
    private static final int INTERVAL_TIME = 1 * MINUTE;


    @Override
    protected int layoutRes() {
        return R.layout.activity_splash_screen;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BaseUrlHolder.setBaseUrl(WebserviceUrls.BASE_URL);
        createHandler();
    }

    private void createHandler() {
        Handler handler = new Handler();
        handler.postDelayed(()->{

            if (Utils.getBoolToPrefs(getApplicationContext(),"isLogin")){
                /*Intent intent = new Intent(SplashScreenActivity.this, MainScreenActivity.class);
                startActivity(intent);
                finish();*/
            }else{
                Intent intent = new Intent(SplashScreenActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }, INTERVAL_TIME);
    }
}
